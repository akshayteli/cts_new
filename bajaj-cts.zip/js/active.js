// $(document).ready(function(){
// 	var link = window.location.href;

// 	if(link.indexOf("dfsc") > -1) {
//        $("bajaj-other-services").removeClass('active');
//        $("#dfsc").addClass(active);
//     }

// 	if(window.location.href.indexOf("vehicleLoyalty") > -1) {
//        $("bajaj-other-services").removeClass('active');
//        $("#vehicleLoyalty").addClass(active);
//     }

// });