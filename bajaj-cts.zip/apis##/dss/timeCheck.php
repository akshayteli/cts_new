<?php

    // $new = new DateTimeZone('Asia/Kolkata');//IST
    // $date = new DateTime(gmdate("m/d/Y H:i:s"), 'Tue, 17 Dec 2013 07:23:56 +0000');
    // $date->setTimezone($new);
    // echo $date->format('m-d-Y H:i:s');


echo "<br/>The time is " . date("h:i:sa");

?>