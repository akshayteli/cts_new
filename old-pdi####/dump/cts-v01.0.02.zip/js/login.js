function  loginCheck(){
	var email=$("#Email").val();
	var password=$("#Passwd").val();
	if((email == "kvsanjay@bajajauto.co.in") && (password=="kvsanjay")) {
				sessionStorage.setItem('username',email);
				window.location = "home.html";	
	} else {
		$('.err_msg').css('visibility','visible');
		$("#Passwd,#Email").val('');
		$("#Email").focus();
	}
	return false;
}
