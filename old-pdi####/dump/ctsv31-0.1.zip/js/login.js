function  loginCheck(){
	var email=$("#Email").val();
	var password=$("#Passwd").val();
	if((email == "kvsanjay@bajajauto.co.in") && (password=="kvsanjay")) {
				sessionStorage.setItem('username',email);
				window.location = "home.html";	
	} else {
		alert("Please Enter Your login Credentials");
		$("#Email").focus();
	}

	return false;
}
